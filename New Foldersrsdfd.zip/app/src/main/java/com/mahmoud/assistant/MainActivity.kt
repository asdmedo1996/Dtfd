@file:OptIn(ExperimentalMaterial3Api::class)

package com.mahmoud.assistant

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val WorkshopColorScheme = lightColorScheme(
    primary = Color(0xFF0D47A1),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFBBDEFB),
    onPrimaryContainer = Color(0xFF0D47A1),
    secondary = Color(0xFF00695C),
    onSecondary = Color.White,
    background = Color(0xFFF1F5F9),
    surface = Color.White
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dbHelper = DatabaseHelper(this)
        setContent {
            MaterialTheme(colorScheme = WorkshopColorScheme) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        WorkshopMainScreen(dbHelper)
                    }
                }
            }
        }
    }
}

@Composable
fun WorkshopMainScreen(dbHelper: DatabaseHelper) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var settings by remember { mutableStateOf(dbHelper.getSettings()) }
    var orders by remember { mutableStateOf(dbHelper.getAllOrders()) }
    var inventory by remember { mutableStateOf(dbHelper.getAllInventory()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = settings.workshopName,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "V2.0",
                                fontSize = 11.sp,
                                color = Color(0xFFFFD54F),
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "حسابات دقيقة • تحسين تقطيع الأعواد • توفير الهالك",
                            fontSize = 11.sp,
                            color = Color(0xFFE3F2FD)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                    label = { Text("الشبابيك") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Build, contentDescription = null) },
                    label = { Text("المطابخ") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = {
                        orders = dbHelper.getAllOrders()
                        selectedTab = 2
                    },
                    icon = { Icon(Icons.Default.Person, contentDescription = null) },
                    label = { Text("المقايسات") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = {
                        inventory = dbHelper.getAllInventory()
                        selectedTab = 3
                    },
                    icon = { Icon(Icons.Default.List, contentDescription = null) },
                    label = { Text("المخزون") }
                )
                NavigationBarItem(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                    label = { Text("الأسعار") }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> WindowsCalculatorTab(
                    settings = settings,
                    onSaveOrder = { custName, custPhone, title, summary, cuttingText, price, deposit ->
                        dbHelper.insertOrder(custName, custPhone, title, summary, cuttingText, price, deposit)
                        orders = dbHelper.getAllOrders()
                    }
                )
                1 -> KitchenCalculatorTab(
                    settings = settings,
                    onSaveOrder = { custName, custPhone, title, summary, cuttingText, price, deposit ->
                        dbHelper.insertOrder(custName, custPhone, title, summary, cuttingText, price, deposit)
                        orders = dbHelper.getAllOrders()
                    }
                )
                2 -> SavedOrdersTab(
                    orders = orders,
                    settings = settings,
                    onDelete = { id ->
                        dbHelper.deleteOrder(id)
                        orders = dbHelper.getAllOrders()
                    }
                )
                3 -> InventoryTab(
                    inventory = inventory,
                    onAdd = { name, cat, qty, unit, minQ ->
                        dbHelper.addInventoryItem(name, cat, qty, unit, minQ)
                        inventory = dbHelper.getAllInventory()
                    },
                    onUpdateQty = { id, newQty ->
                        dbHelper.updateInventoryQty(id, newQty)
                        inventory = dbHelper.getAllInventory()
                    },
                    onDelete = { id ->
                        dbHelper.deleteInventoryItem(id)
                        inventory = dbHelper.getAllInventory()
                    }
                )
                4 -> SettingsTab(
                    currentSettings = settings,
                    onSaveSettings = { updated ->
                        dbHelper.updateSettings(updated)
                        settings = dbHelper.getSettings()
                    }
                )
            }
        }
    }
}

@Composable
fun WindowsCalculatorTab(
    settings: WorkshopSettings,
    onSaveOrder: (String, String, String, String, String, Double, Double) -> Unit
) {
    val context = LocalContext.current
    var selectedProfile by remember { mutableStateOf(ProfileSystem.PS_SMALL) }
    var widthText by remember { mutableStateOf("120") }
    var heightText by remember { mutableStateOf("120") }
    var sashCount by remember { mutableIntStateOf(2) }
    var hasFlyScreen by remember { mutableStateOf(true) }
    var selectedGlass by remember { mutableStateOf(GlassType.SINGLE_6MM) }

    var customerName by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }
    var depositText by remember { mutableStateOf("0") }

    val widthCm = widthText.toDoubleOrNull() ?: 120.0
    val heightCm = heightText.toDoubleOrNull() ?: 120.0

    val result = remember(selectedProfile, widthCm, heightCm, sashCount, hasFlyScreen, selectedGlass, settings) {
        AlumitalCalculator.calculateWindow(
            profile = selectedProfile,
            widthCm = widthCm,
            heightCm = heightCm,
            sashCount = sashCount,
            hasFlyScreen = hasFlyScreen,
            glassType = selectedGlass,
            settings = settings
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // بطاقة اختيار النظام
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "1. تحديد القطاع والمقاسات:",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ProfileSystem.values().forEach { prof ->
                        FilterChip(
                            selected = selectedProfile == prof,
                            onClick = {
                                selectedProfile = prof
                                if (prof.isHinged && sashCount > 2) sashCount = 2
                            },
                            label = { Text(prof.titleAr) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = widthText,
                        onValueChange = { widthText = it },
                        label = { Text("العرض (سم)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = heightText,
                        onValueChange = { heightText = it },
                        label = { Text("الارتفاع (سم)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text("عدد الضلف:", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val options = if (selectedProfile.isHinged) listOf(1, 2) else listOf(2, 3, 4)
                    options.forEach { count ->
                        FilterChip(
                            selected = sashCount == count,
                            onClick = { sashCount = count },
                            label = { Text("$count ضلفة") }
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { hasFlyScreen = !hasFlyScreen }
                ) {
                    Checkbox(checked = hasFlyScreen, onCheckedChange = { hasFlyScreen = it })
                    Text("إضافة ضلفة سلك ناموسية")
                }

                Text("نوع الزجاج:", fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    GlassType.values().forEach { g ->
                        FilterChip(
                            selected = selectedGlass == g,
                            onClick = { selectedGlass = g },
                            label = { Text(g.titleAr) }
                        )
                    }
                }
            }
        }

        // الرسم التخطيطي 2D
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "معاينة 2D (${result.widthCm}×${result.heightCm} سم | المساحة: ${result.areaSqM} م²)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Window2DPreview(
                    widthCm = result.widthCm,
                    heightCm = result.heightCm,
                    sashCount = result.sashCount,
                    isHinged = selectedProfile.isHinged
                )
            }
        }

        // ميزة V2 الجديدة: خوارزمية توزيع تقطيع الأعواد (Cutting Stock Optimizer)
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "⚡ خطة تقطيع الأعواد الذكية (V2):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFF166534)
                    )
                    Text(
                        text = "مطلوب ${result.optimization.totalBarsNeeded} عود (6م)",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF15803D),
                        fontSize = 13.sp
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "هالك الأعواد الفعلي: ${result.optimization.wastePercentage}% (إجمالي فضل: ${result.optimization.totalWasteCm} سم)",
                    fontSize = 12.sp,
                    color = Color.DarkGray
                )
                Spacer(modifier = Modifier.height(8.dp))

                result.optimization.barPlans.forEach { plan ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .background(Color.White, RoundedCornerShape(6.dp))
                            .border(1.dp, Color(0xFFDCFCE7), RoundedCornerShape(6.dp))
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "عود رقم ${plan.barIndex}:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color(0xFF166534)
                            )
                            Text(
                                text = "الفضل الباقي: ${plan.wasteLengthCm} سم",
                                fontSize = 12.sp,
                                color = if (plan.wasteLengthCm > 50) Color(0xFFD97706) else Color.Gray,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "القطع: " + plan.cuts.joinToString(" + ") { "${it}سم" },
                            fontSize = 12.sp,
                            color = Color(0xFF1E293B)
                        )
                    }
                }
            }
        }

        // تفصيل القطع الفردية
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "2. جدول تفصيل القطع (أمر تصنيع):",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))

                result.cuttingList.forEach { piece ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .background(Color(0xFFF8FAFC), RoundedCornerShape(6.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(piece.partName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(piece.notes, fontSize = 11.sp, color = Color.Gray)
                        }
                        Text(
                            text = "${piece.lengthCm} سم × ${piece.count}",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0D47A1),
                            fontSize = 13.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Divider()
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "• مقاس الزجاج: ${result.glassWidthCm} سم × ${result.glassHeightCm} سم (عدد ${result.glassPanelsCount} لوح - صافي ${result.netGlassAreaSqM} م²)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "• وزن الألوميتال الصافي: ${result.estimatedWeightKg} كجم (بالهالك ${settings.wastePercentage}%: ${result.weightWithWasteKg} كجم)",
                    fontSize = 12.sp
                )
            }
        }

        // التكلفة والتسعير
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "3. التكلفة وعرض السعر (جنيه مصري):",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color(0xFF1E3A8A)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text("• الخامات والأعواد: ${result.materialCostEgp} ج.م | الزجاج: ${result.glassCostEgp} ج.م")
                Text("• الإكسسوارات والسلك: ${result.accessoriesCostEgp} ج.م | المصنعية: ${result.laborCostEgp} ج.م")
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "الإجمالي المطلوب: ${result.totalPriceEgp} ج.م (المتر: ${result.pricePerSqMEgp} ج.م)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color(0xFF0D47A1)
                )

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        label = { Text("اسم العميل") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = depositText,
                        onValueChange = { depositText = it },
                        label = { Text("العربون") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val optSummary = "مطلوب ${result.optimization.totalBarsNeeded} عود (هالك ${result.optimization.wastePercentage}%)"
                            val summary = "مقاس ${result.widthCm}×${result.heightCm} سم (${result.sashCount} ضلفة) - $optSummary"
                            val cuttingTxt = result.cuttingList.joinToString("\n") {
                                "${it.partName}: ${it.lengthCm} سم × ${it.count}"
                            }
                            onSaveOrder(
                                customerName,
                                customerPhone,
                                selectedProfile.titleAr,
                                summary,
                                cuttingTxt,
                                result.totalPriceEgp,
                                depositText.toDoubleOrNull() ?: 0.0
                            )
                            Toast.makeText(context, "تم حفظ المقايسة بنجاح", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("حفظ المقايسة")
                    }

                    OutlinedButton(
                        onClick = {
                            val lines = listOf(
                                "القطاع: ${selectedProfile.titleAr} (${selectedProfile.category})",
                                "المقاس: ${result.widthCm} سم × ${result.heightCm} سم (${result.sashCount} ضلفة) - مساحة ${result.areaSqM} م²",
                                "الزجاج: ${selectedGlass.titleAr} (${result.glassWidthCm}×${result.glassHeightCm} سم)",
                                "الوزن التقديري بالهالك: ${result.weightWithWasteKg} كجم"
                            )
                            PdfExporter.exportAndShareOrderPdf(
                                context = context,
                                settings = settings,
                                customerName = customerName,
                                title = selectedProfile.titleAr,
                                summaryLines = lines,
                                cuttingList = result.cuttingList,
                                totalPriceEgp = result.totalPriceEgp,
                                optimization = result.optimization
                            )
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تصدير PDF")
                    }
                }
            }
        }
    }
}

@Composable
fun Window2DPreview(
    widthCm: Double,
    heightCm: Double,
    sashCount: Int,
    isHinged: Boolean
) {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(160.dp)
            .background(Color(0xFFF8FAFC), RoundedCornerShape(8.dp))
            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp))
            .padding(14.dp)
    ) {
        val ratio = (widthCm / heightCm).coerceIn(0.5, 2.2).toFloat()
        val maxH = size.height * 0.85f
        val maxW = size.width * 0.85f
        var rectW = maxH * ratio
        var rectH = maxH
        if (rectW > maxW) {
            rectW = maxW
            rectH = maxW / ratio
        }
        val startX = (size.width - rectW) / 2f
        val startY = (size.height - rectH) / 2f

        drawRect(
            color = Color(0xFFBAE6FD),
            topLeft = Offset(startX, startY),
            size = Size(rectW, rectH)
        )

        drawRect(
            color = Color(0xFF0F172A),
            topLeft = Offset(startX, startY),
            size = Size(rectW, rectH),
            style = Stroke(width = 8f)
        )

        val cellW = rectW / sashCount
        for (i in 0 until sashCount) {
            val x = startX + i * cellW
            drawRect(
                color = Color(0xFF0284C7),
                topLeft = Offset(x + 4f, startY + 4f),
                size = Size(cellW - 8f, rectH - 8f),
                style = Stroke(width = 4f)
            )
            val midY = startY + rectH / 2f
            if (isHinged) {
                val openLeft = (i % 2 == 0)
                if (openLeft) {
                    drawLine(Color(0xFF0369A1), Offset(x + 6f, startY + 6f), Offset(x + cellW - 6f, midY), 2f)
                    drawLine(Color(0xFF0369A1), Offset(x + 6f, startY + rectH - 6f), Offset(x + cellW - 6f, midY), 2f)
                } else {
                    drawLine(Color(0xFF0369A1), Offset(x + cellW - 6f, startY + 6f), Offset(x + 6f, midY), 2f)
                    drawLine(Color(0xFF0369A1), Offset(x + cellW - 6f, startY + rectH - 6f), Offset(x + 6f, midY), 2f)
                }
            } else {
                drawLine(Color(0xFF0D47A1), Offset(x + cellW * 0.3f, midY), Offset(x + cellW * 0.7f, midY), 3f)
            }
        }
    }
}

@Composable
fun KitchenCalculatorTab(
    settings: WorkshopSettings,
    onSaveOrder: (String, String, String, String, String, Double, Double) -> Unit
) {
    val context = LocalContext.current
    var unitType by remember { mutableStateOf(KitchenUnitType.LOWER_UNIT) }
    var claddingType by remember { mutableStateOf(KitchenCladdingType.CLADDING) }
    var widthText by remember { mutableStateOf("100") }
    var heightText by remember { mutableStateOf("85") }
    var depthText by remember { mutableStateOf("60") }
    var doorsText by remember { mutableStateOf("2") }
    var drawersText by remember { mutableStateOf("1") }
    var shelvesText by remember { mutableStateOf("1") }
    var customerName by remember { mutableStateOf("") }

    val res = remember(unitType, claddingType, widthText, heightText, depthText, doorsText, drawersText, shelvesText, settings) {
        AlumitalCalculator.calculateKitchenUnit(
            unitType = unitType,
            claddingType = claddingType,
            widthCm = widthText.toDoubleOrNull() ?: 100.0,
            heightCm = heightText.toDoubleOrNull() ?: 85.0,
            depthCm = depthText.toDoubleOrNull() ?: 60.0,
            doorsCount = doorsText.toIntOrNull() ?: 2,
            drawersCount = drawersText.toIntOrNull() ?: 0,
            shelvesCount = shelvesText.toIntOrNull() ?: 1,
            settings = settings
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "حاسبة وحدات المطابخ الألوميتال والكلادينج:",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KitchenUnitType.values().forEach { u ->
                        FilterChip(
                            selected = unitType == u,
                            onClick = {
                                unitType = u
                                when (u) {
                                    KitchenUnitType.LOWER_UNIT -> { heightText = "85"; depthText = "60" }
                                    KitchenUnitType.UPPER_UNIT -> { heightText = "70"; depthText = "35"; drawersText = "0" }
                                    KitchenUnitType.TALL_PANTRY -> { heightText = "210"; depthText = "60" }
                                }
                            },
                            label = { Text(u.titleAr) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text("نوع الحشو والتجليد:", fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    KitchenCladdingType.values().forEach { c ->
                        FilterChip(
                            selected = claddingType == c,
                            onClick = { claddingType = c },
                            label = { Text(c.titleAr) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = widthText,
                        onValueChange = { widthText = it },
                        label = { Text("العرض (سم)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = heightText,
                        onValueChange = { heightText = it },
                        label = { Text("الارتفاع (سم)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = depthText,
                        onValueChange = { depthText = it },
                        label = { Text("العمق (سم)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = doorsText,
                        onValueChange = { doorsText = it },
                        label = { Text("عدد الضلف") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = drawersText,
                        onValueChange = { drawersText = it },
                        label = { Text("عدد الأدراج") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = shelvesText,
                        onValueChange = { shelvesText = it },
                        label = { Text("عدد الأرفف") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "قائمة القص والخامات للوحدة:",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))
                res.cuttingSummary.forEach { piece ->
                    Text("• ${piece.partName}: ${piece.lengthCm} سم × ${piece.count} قطعة (${piece.notes})")
                }
                Spacer(modifier = Modifier.height(6.dp))
                Divider()
                Spacer(modifier = Modifier.height(6.dp))
                Text("• إجمالي أعواد الألومنيوم: ${res.aluminumMeters} م.ط (الوزن بالهالك: ${res.aluminumWeightKg} كجم)")
                Text("• مساحة ألواح (${claddingType.titleAr}): ${res.claddingAreaSqM} م²")
                Text("• التكلفة: ألومنيوم ${res.aluminumCostEgp} ج.م | تجليد ${res.claddingCostEgp} ج.م | إكسسوار ومصنعية ${res.accessoriesCostEgp + res.laborCostEgp} ج.م")
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "إجمالي تكلفة وحدة المطبخ: ${res.totalPriceEgp} جنيه مصري",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color(0xFF0D47A1)
                )

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = customerName,
                    onValueChange = { customerName = it },
                    label = { Text("اسم العميل") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            val sum = "${unitType.titleAr} (${res.widthCm}×${res.heightCm}×${res.depthCm} سم) - ${claddingType.titleAr}"
                            val cutTxt = res.cuttingSummary.joinToString("\n") { "${it.partName}: ${it.lengthCm} سم × ${it.count}" }
                            onSaveOrder(customerName, "", "مطبخ - ${unitType.titleAr}", sum, cutTxt, res.totalPriceEgp, 0.0)
                            Toast.makeText(context, "تم حفظ وحدة المطبخ", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("حفظ المقايسة")
                    }
                    OutlinedButton(
                        onClick = {
                            PdfExporter.exportAndShareOrderPdf(
                                context = context,
                                settings = settings,
                                customerName = customerName,
                                title = "وحدة مطبخ - ${unitType.titleAr}",
                                summaryLines = listOf(
                                    "المقاس: ${res.widthCm}×${res.heightCm}×${res.depthCm} سم",
                                    "التجليد: ${claddingType.titleAr} (${res.claddingAreaSqM} م²)",
                                    "الوزن التقديري للألومنيوم: ${res.aluminumWeightKg} كجم"
                                ),
                                cuttingList = res.cuttingSummary,
                                totalPriceEgp = res.totalPriceEgp
                            )
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("تصدير PDF")
                    }
                }
            }
        }
    }
}

@Composable
fun SavedOrdersTab(
    orders: List<SavedOrder>,
    settings: WorkshopSettings,
    onDelete: (Long) -> Unit
) {
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        val totalAll = orders.sumOf { it.totalPriceEgp }
        val totalPaid = orders.sumOf { it.paidDepositEgp }
        val totalRem = totalAll - totalPaid

        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("ملخص حسابات العملاء وأوامر الشغل:", fontWeight = FontWeight.Bold)
                Text("المقايسات المسجلة: ${orders.size} أمر شغل")
                Text("الإجمالي: $totalAll ج.م | المحصل: $totalPaid ج.م | المتبقي: $totalRem ج.م")
            }
        }

        if (orders.isEmpty()) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "لا توجد مقايسات مسجلة بعد.",
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            orders.forEach { order ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${order.customerName} - ${order.itemTitle}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(order.createdAt, fontSize = 11.sp, color = Color.Gray)
                            }
                            Row {
                                IconButton(
                                    onClick = {
                                        val pieces = order.cuttingDetailsText.split("\n").mapNotNull { line ->
                                            if (line.isBlank()) null
                                            else CuttingPiece(line, 0.0, 1, "سجل سابق")
                                        }
                                        PdfExporter.exportAndShareOrderPdf(
                                            context = context,
                                            settings = settings,
                                            customerName = order.customerName,
                                            title = order.itemTitle,
                                            summaryLines = listOf(
                                                order.detailsSummary,
                                                "عربون: ${order.paidDepositEgp} ج.م | متبقي: ${order.totalPriceEgp - order.paidDepositEgp} ج.م"
                                            ),
                                            cuttingList = pieces,
                                            totalPriceEgp = order.totalPriceEgp
                                        )
                                    }
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = "PDF")
                                }
                                IconButton(onClick = { onDelete(order.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color(0xFFD32F2F))
                                }
                            }
                        }
                        Text(order.detailsSummary, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "الإجمالي: ${order.totalPriceEgp} ج.م | المتبقي: ${order.totalPriceEgp - order.paidDepositEgp} ج.م",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1B5E20)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun InventoryTab(
    inventory: List<InventoryItem>,
    onAdd: (String, String, Double, String, Double) -> Unit,
    onUpdateQty: (Long, Double) -> Unit,
    onDelete: (Long) -> Unit
) {
    var nameText by remember { mutableStateOf("") }
    var catText by remember { mutableStateOf("قطاعات ألوميتال") }
    var qtyText by remember { mutableStateOf("10") }
    var unitText by remember { mutableStateOf("عود") }
    var minText by remember { mutableStateOf("5") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("إضافة صنف لمخزن الورشة:", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = nameText,
                    onValueChange = { nameText = it },
                    label = { Text("اسم الصنف (مثال: عود حلق جامبو)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = qtyText,
                        onValueChange = { qtyText = it },
                        label = { Text("الكمية") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = unitText,
                        onValueChange = { unitText = it },
                        label = { Text("الوحدة") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = minText,
                        onValueChange = { minText = it },
                        label = { Text("حد النواقص") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        if (nameText.isNotBlank()) {
                            onAdd(
                                nameText,
                                catText,
                                qtyText.toDoubleOrNull() ?: 0.0,
                                unitText.ifBlank { "قطعة" },
                                minText.toDoubleOrNull() ?: 2.0
                            )
                            nameText = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("إضافة للمخزن")
                }
            }
        }

        inventory.forEach { item ->
            val isLow = item.quantity <= item.minAlertQty
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isLow) Color(0xFFFFEBEE) else Color.White
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.itemName, fontWeight = FontWeight.Bold)
                        Text(
                            text = if (isLow) "⚠️ تنبيه نواقص! الرصيد: ${item.quantity} ${item.unitName}"
                            else "الرصيد: ${item.quantity} ${item.unitName}",
                            color = if (isLow) Color(0xFFC62828) else Color(0xFF2E7D32),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { onUpdateQty(item.id, item.quantity - 1.0) }) { Text("-1") }
                        Spacer(modifier = Modifier.width(4.dp))
                        OutlinedButton(onClick = { onUpdateQty(item.id, item.quantity + 1.0) }) { Text("+1") }
                        IconButton(onClick = { onDelete(item.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsTab(
    currentSettings: WorkshopSettings,
    onSaveSettings: (WorkshopSettings) -> Unit
) {
    val context = LocalContext.current
    var workshopName by remember(currentSettings) { mutableStateOf(currentSettings.workshopName) }
    var phone by remember(currentSettings) { mutableStateOf(currentSettings.engineerPhone) }
    var alumKgPrice by remember(currentSettings) { mutableStateOf(currentSettings.aluminumKgPriceEgp.toString()) }
    var upvcPrice by remember(currentSettings) { mutableStateOf(currentSettings.upvcMeterPriceEgp.toString()) }
    var glassPrice by remember(currentSettings) { mutableStateOf(currentSettings.glassSingleSqMPriceEgp.toString()) }
    var slidingAcc by remember(currentSettings) { mutableStateOf(currentSettings.accessoriesSlidingKitEgp.toString()) }
    var hingedAcc by remember(currentSettings) { mutableStateOf(currentSettings.accessoriesHingedKitEgp.toString()) }
    var screenPrice by remember(currentSettings) { mutableStateOf(currentSettings.flyScreenMeterPriceEgp.toString()) }
    var laborPrice by remember(currentSettings) { mutableStateOf(currentSettings.laborPerSqMEgp.toString()) }
    var wastePct by remember(currentSettings) { mutableStateOf(currentSettings.wastePercentage.toString()) }
    var kitchenClad by remember(currentSettings) { mutableStateOf(currentSettings.kitchenCladdingSqMPriceEgp.toString()) }
    var barLength by remember(currentSettings) { mutableStateOf(currentSettings.stockBarLengthCm.toString()) }
    var kerf by remember(currentSettings) { mutableStateOf(currentSettings.sawKerfCm.toString()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "إعدادات الورشة والأسعار المعتمدة (ج.م):",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedTextField(
                    value = workshopName,
                    onValueChange = { workshopName = it },
                    label = { Text("اسم الورشة / المكتب الهندسي") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("رقم التليفون") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = alumKgPrice,
                        onValueChange = { alumKgPrice = it },
                        label = { Text("سعر كيلو الألوميتال") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = upvcPrice,
                        onValueChange = { upvcPrice = it },
                        label = { Text("سعر متر UPVC") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = glassPrice,
                        onValueChange = { glassPrice = it },
                        label = { Text("سعر م² زجاج 6مم") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = laborPrice,
                        onValueChange = { laborPrice = it },
                        label = { Text("المصنعية/م²") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = barLength,
                        onValueChange = { barLength = it },
                        label = { Text("طول العود الخام (سم)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = kerf,
                        onValueChange = { kerf = it },
                        label = { Text("سمك صينية المنشار (سم)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = slidingAcc,
                        onValueChange = { slidingAcc = it },
                        label = { Text("إكسسوار جرار") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = wastePct,
                        onValueChange = { wastePct = it },
                        label = { Text("الهالك التقديري %") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Button(
                    onClick = {
                        val updated = WorkshopSettings(
                            workshopName = workshopName.ifBlank { "مساعد المهندس محمود عبد النبي الطويل" },
                            engineerPhone = phone,
                            aluminumKgPriceEgp = alumKgPrice.toDoubleOrNull() ?: 245.0,
                            upvcMeterPriceEgp = upvcPrice.toDoubleOrNull() ?: 190.0,
                            glassSingleSqMPriceEgp = glassPrice.toDoubleOrNull() ?: 450.0,
                            accessoriesSlidingKitEgp = slidingAcc.toDoubleOrNull() ?: 320.0,
                            accessoriesHingedKitEgp = hingedAcc.toDoubleOrNull() ?: 280.0,
                            flyScreenMeterPriceEgp = screenPrice.toDoubleOrNull() ?: 250.0,
                            laborPerSqMEgp = laborPrice.toDoubleOrNull() ?: 350.0,
                            wastePercentage = wastePct.toDoubleOrNull() ?: 8.0,
                            kitchenCladdingSqMPriceEgp = kitchenClad.toDoubleOrNull() ?: 520.0,
                            kitchenAccessorySetEgp = currentSettings.kitchenAccessorySetEgp,
                            stockBarLengthCm = barLength.toDoubleOrNull() ?: 600.0,
                            sawKerfCm = kerf.toDoubleOrNull() ?: 0.4
                        )
                        onSaveSettings(updated)
                        Toast.makeText(context, "تم حفظ الإعدادات بنجاح", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20))
                ) {
                    Icon(Icons.Default.Check, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("حفظ التعديلات")
                }
            }
        }
    }
}
