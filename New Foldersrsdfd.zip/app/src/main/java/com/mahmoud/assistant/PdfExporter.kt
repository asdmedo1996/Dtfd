package com.mahmoud.assistant

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

object PdfExporter {

    fun exportAndShareOrderPdf(
        context: Context,
        settings: WorkshopSettings,
        customerName: String,
        title: String,
        summaryLines: List<String>,
        cuttingList: List<CuttingPiece>,
        totalPriceEgp: Double,
        optimization: BarOptimizationResult? = null
    ) {
        try {
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val headerPaint = Paint().apply {
                color = Color.rgb(13, 71, 161)
                textSize = 17f
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }
            val subHeaderPaint = Paint().apply {
                color = Color.DKGRAY
                textSize = 12f
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }
            val bodyPaint = Paint().apply {
                color = Color.BLACK
                textSize = 11f
                textAlign = Paint.Align.RIGHT
            }
            val accentPaint = Paint().apply {
                color = Color.rgb(0, 105, 92)
                textSize = 11f
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }
            val linePaint = Paint().apply {
                color = Color.LTGRAY
                strokeWidth = 1.2f
            }

            var y = 40f
            val rightMargin = 555f

            // الترويسة
            canvas.drawText(settings.workshopName, rightMargin, y, headerPaint)
            y += 20f
            canvas.drawText("هاتف التواصل الهندسي: ${settings.engineerPhone}", rightMargin, y, subHeaderPaint)
            y += 14f
            canvas.drawLine(40f, y, rightMargin, y, linePaint)

            // بيانات أمر الشغل
            y += 24f
            canvas.drawText("أمر تصنيع وعرض سعر V2: $title", rightMargin, y, headerPaint)
            y += 18f
            canvas.drawText("العميل: ${customerName.ifBlank { "عميل نقدي" }}", rightMargin, y, subHeaderPaint)

            y += 20f
            for (line in summaryLines) {
                canvas.drawText(line, rightMargin, y, bodyPaint)
                y += 16f
            }

            // إذا توفرت خطة تقطيع الأعواد (Optimization)
            if (optimization != null && optimization.barPlans.isNotEmpty()) {
                y += 8f
                canvas.drawLine(40f, y, rightMargin, y, linePaint)
                y += 18f
                canvas.drawText(
                    "خطة تقطيع الأعواد (تقليل الهالك): مطلوب ${optimization.totalBarsNeeded} عود (الهالك: ${optimization.wastePercentage}%)",
                    rightMargin,
                    y,
                    accentPaint
                )
                y += 16f
                for (plan in optimization.barPlans.take(5)) {
                    val cutsStr = plan.cuts.joinToString(" + ") { "${it}سم" }
                    val planText = "• عود ${plan.barIndex}: [$cutsStr] -> مستخدم ${plan.usedLengthCm} سم | الباقي فضل ${plan.wasteLengthCm} سم"
                    canvas.drawText(planText, rightMargin, y, bodyPaint)
                    y += 15f
                }
            }

            y += 8f
            canvas.drawLine(40f, y, rightMargin, y, linePaint)
            y += 20f
            canvas.drawText("جدول تفصيل القطع وقوائم القص الفردية:", rightMargin, y, subHeaderPaint)
            y += 18f

            for (piece in cuttingList) {
                if (y > 770f) break
                val rowText = "• ${piece.partName} | الطول: ${piece.lengthCm} سم | العدد: ${piece.count} (${piece.notes})"
                canvas.drawText(rowText, rightMargin, y, bodyPaint)
                y += 16f
            }

            y += 12f
            canvas.drawLine(40f, y, rightMargin, y, linePaint)
            y += 24f
            canvas.drawText(
                "الإجمالي المطلوب: $totalPriceEgp جنيه مصري",
                rightMargin,
                y,
                headerPaint
            )

            pdfDocument.finishPage(page)

            val pdfDir = File(context.cacheDir, "pdfs")
            if (!pdfDir.exists()) pdfDir.mkdirs()
            val pdfFile = File(pdfDir, "أمر_تصنيع_V2_${System.currentTimeMillis()}.pdf")

            FileOutputStream(pdfFile).use { out ->
                pdfDocument.writeTo(out)
            }
            pdfDocument.close()

            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                pdfFile
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "أمر تصنيع وعرض سعر - ${settings.workshopName}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "مشاركة أو طباعة PDF"))

        } catch (e: Exception) {
            Toast.makeText(
                context,
                "خطأ في إنشاء PDF: ${e.localizedMessage}",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
